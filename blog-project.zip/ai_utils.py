from transformers import pipeline
from keybert import KeyBERT
from sentence_transformers import SentenceTransformer

emotion_classifier = pipeline(
    "text-classification",
    model="j-hartmann/emotion-english-distilroberta-base",
    return_all_scores=True
)

def analyze_emotion_top3(text):
    try:
        scores = emotion_classifier(text)[0]
        sorted_scores = sorted(scores, key=lambda x: x['score'], reverse=True)[:3]
        return [(s['label'], round(s['score'] * 100, 1)) for s in sorted_scores]
    except Exception as e:
        print(f"[Emotion analysis error]: {e}")
        return []

embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
kw_model = KeyBERT(model=embedding_model)

def generate_tags(text, top_n=4):
    try:
        keywords = kw_model.extract_keywords(
            text,
            keyphrase_ngram_range=(1, 1), 
            stop_words='english',
            top_n=top_n * 2, 
            use_maxsum=True,
            diversity=0.7
        )

        tags = []
        for kw, _ in keywords:
            tag = kw.strip().lower()
            if tag.isalpha() and tag not in tags:
                tags.append(tag)
            if len(tags) == top_n:
                break

        while len(tags) < top_n:
            if 'general' not in tags:
                tags.append('general')
            else:
                tags.append(f'general{len(tags)}')

        return tags
    except Exception as e:
        print(f"[Tag generation error]: {e}")
        return ['general'] * top_n
