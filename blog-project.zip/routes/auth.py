from flask import Blueprint, render_template, redirect, url_for, flash, request, session, current_app
from app import db 
from models import User, Post  
from forms import RegistrationForm, LoginForm, EditProfileForm 
from werkzeug.security import generate_password_hash, check_password_hash 
from werkzeug.utils import secure_filename 
import os  

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm() 
    if form.validate_on_submit(): 
        hashed_password = generate_password_hash(form.password.data) 
        user = User(username=form.username.data, email=form.email.data, password_hash=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created!', 'success')
        return redirect(url_for('auth.login'))
    return render_template('register.html', form=form)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm() 
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            session['user_id'] = user.id
            session['username'] = user.username
            session['avatar'] = user.avatar
            session.permanent = True 
            flash('Login successful!', 'success') 
            return redirect(url_for('posts.home'))  
        else:
            flash('Login unsuccessful. Please check email and password', 'danger') 
    return render_template('login.html', form=form)


@auth_bp.route('/logout')
def logout():
    session.clear() 
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))  


@auth_bp.route('/profile')
def profile():
    if 'user_id' not in session: 
        flash('Please login to view your profile.', 'warning') 
        return redirect(url_for('auth.login'))  

    user = User.query.get_or_404(session['user_id']) 
    posts = Post.query.filter_by(user_id=user.id).all()

    return render_template('profile.html', user=user, posts=posts)


@auth_bp.route('/profile/edit', methods=['GET', 'POST'])
def edit_profile():
    if 'user_id' not in session:
        flash('Please login to edit your profile.', 'warning')
        return redirect(url_for('auth.login')) 

    user = User.query.get_or_404(session['user_id']) 

    form = EditProfileForm()
    if form.validate_on_submit(): 
        user.username = form.username.data 
        user.email = form.email.data

        if form.avatar.data: 
            filename = secure_filename(form.avatar.data.filename)
            avatar_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename) 
            form.avatar.data.save(avatar_path)  
            user.avatar = filename 
            session['avatar'] = filename 

        db.session.commit() 
        session['username'] = user.username 
        flash('Your profile has been updated!', 'success')  
        return redirect(url_for('auth.profile')) 

    form.username.data = user.username
    form.email.data = user.email

    return render_template('edit_profile.html', form=form) 
